export declare const dragManager: any;
