import { InputEditor } from "./InputEditor";
import { List } from "../List";
import { IListItem } from "../types";
export declare function getEditor(item: IListItem, list: List): InputEditor;
