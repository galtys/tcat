import { Inputs } from "./Inputs";
export declare class InputsGroup extends Inputs {
    toVDOM(): any;
}
