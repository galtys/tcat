export declare class Empty {
    toVDOM(): any;
    private _getIcon;
}
