import { IShapeToolbarConfig } from "../../../ts-diagram";
export declare const orgShapeToolbar: IShapeToolbarConfig[];
export declare const mindmapShapeToolbar: IShapeToolbarConfig[];
export declare const defaultShapeToolbar: IShapeToolbarConfig[];
