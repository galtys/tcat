import { ICol, IRow } from "./../types";
export declare function getWidth(columns: ICol[], colspan: number, index: number): number;
export declare function getHeight(dataRows: IRow[], rowspan: number, index: number): number;
