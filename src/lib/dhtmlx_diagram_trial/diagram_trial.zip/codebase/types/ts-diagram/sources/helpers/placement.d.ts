import { ShapesCollection } from "../ShapesCollection";
import { IDiagramConfig } from "../types";
export declare function setHeaderColor(data: ShapesCollection, config?: IDiagramConfig): void;
