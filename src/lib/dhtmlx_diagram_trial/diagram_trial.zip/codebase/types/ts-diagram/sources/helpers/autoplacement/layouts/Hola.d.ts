import { IGraph } from "../types";
export default class Hola {
    layout(g: IGraph, config: any): IGraph;
}
