import "../../styles/diagram.scss";
export { Diagram } from "./Diagram";
export { awaitRedraw } from "../../ts-common/dom";
export declare const i18n: any;
