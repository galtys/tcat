import { IGraph } from "../types";
export default class SymmetricTree {
    private _step;
    constructor();
    layout(g: IGraph, config: any): IGraph;
    private _layout;
    private _layout_place;
    private _getStep;
}
