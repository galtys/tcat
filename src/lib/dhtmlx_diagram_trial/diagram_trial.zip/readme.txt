/*
@license

dhtmlxDiagram v.3.1.0 Professional
This software is covered by Evaluation License. Usage without proper license is prohibited.

(c) XB Software.
*/


Useful links
-------------

- Online  documentation
	https://docs.dhtmlx.com/