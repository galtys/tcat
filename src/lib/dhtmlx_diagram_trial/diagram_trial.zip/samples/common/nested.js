var nestedLists = [
	{
		"id": 1,
		"text": "item: 1",
	},
	{
		"id": 2,
		"text": "item: 2",
		"parent": 1,
		dir: "vertical"
	},
	{
		"id": 3,
		"text": "item: 3",
		"parent": 14,
		dir: "vertical"
	},
	{
		"id": 4,
		"text": "item: 4",
		"parent": 10
	},
	{
		"id": 5,
		"text": "item: 5",
		"parent": 3
	},
	{
		"id": 6,
		"text": "item: 6",
		"parent": 20
	},
	{
		"id": 7,
		"text": "item: 7",
		"parent": 14
	},
	{
		"id": 8,
		"text": "item: 8",
		"parent": 3
	},
	{
		"id": 10,
		"text": "item: 10",
		"parent": 1,
		dir: "vertical"
	},
	{
		"id": 11,
		"text": "item: 11",
		"parent": 12
	},
	{
		"id": 12,
		"text": "item: 12",
		"parent": 20
	},
	{
		"id": 13,
		"text": "item: 13",
		"parent": 10
	},
	{
		"id": 14,
		"text": "item: 14",
		"parent": 2,
		 dir:"vertical"
	},
	{
		"id": 16,
		"text": "item: 16",
		"parent": 12
	},
	{
		"id": 17,
		"text": "item: 17",
		"parent": 1
	},
	{
		"id": 18,
		"text": "item: 18",
		"parent": 14
	},
	{
		"id": 19,
		"text": "item: 19",
		"parent": 2
	},
	{
		"id": 20,
		"text": "item: 20",
		"parent": 20
	},
	{
		"id": 21,
		"text": "item: 21",
		"parent": 14
	},
	{
		"id": 22,
		"text": "item: 22",
		"parent": 2
	},
	{
		"id": 23,
		"text": "item: 23",
		"parent": 3
	},
	{
		"id": 24,
		"text": "item: 24",
		"parent": 1,
		dir: "vertical"
	},
	{
		"id": 25,
		"text": "item: 25",
		"parent": 12
	},
	{
		"id": 26,
		"text": "item: 26",
		"parent": 12
	},
	{
		"id": 27,
		"text": "item: 27",
		"parent": 14
	},
	{
		"id": 28,
		"text": "item: 28",
		"parent": 24
	},
	{
		"id": 29,
		"text": "item: 29",
		"parent": 10
	},
	{
		"id": 30,
		"text": "item: 30",
		"parent": 10
	},
	{
		"id": 31,
		"text": "item: 31",
		"parent": 24
	},
	{
		"id": 32,
		"text": "item: 32",
		"parent": 14
	},
	{
		"id": 33,
		"text": "item: 33",
		"parent": 28
	},
	{
		"id": 34,
		"text": "item: 34",
		"parent": 28
	},
	{
		"id": 35,
		"text": "item: 35",
		"parent": 3
	},
	{
		"id": 36,
		"text": "item: 36",
		"parent": 34
	},
	{
		"id": 37,
		"text": "item: 37",
		"parent": 3
	},
	{
		"id": 38,
		"text": "item: 38",
		"parent": 3
	},
	{
		"id": 39,
		"text": "item: 39",
		"parent": 3
	},
	{
		"id": 40,
		"text": "item: 40",
		"parent": 3
	}
]